package com.ssafy.day02.a_person;

public class Person {

	String name;
	int age;
	boolean isHungry;
	
	// 생성자 오버로딩
	public Person() {
		this("아무개", 0, false);
	}
	
	public Person(String name, int age) {
		this(name, age, false);
	}
	
	public Person(String name, int age, boolean isHungry) {
		this.name = name;
		this.age = age;
		this.isHungry = isHungry;
	}
	
	void eat() {
		System.out.println("냠냠");
		this.isHungry = false;
	}
	
	void work() {
		System.out.println("열심");
		this.isHungry = true;
	}
	
	void printInfo() {
		System.out.println(name+ " : " + age + " : " + isHungry);
	}
}
