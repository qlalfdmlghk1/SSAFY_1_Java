package com.ssafy.day02.a_person;

public class PersonTest {

	public static void main(String[] args) {
		int i = 10;
//		Person p1 = new Person(); //  구체화 0x100
//		p1.name = "홍길동";
//		p1.age = 10;
//		p1.eat();
		
		Person p1 = new Person("홍길동", 10, true);
		
//		Person p2 = new Person(); // 구체화
//		p2.name = "tony";
//		p2.age = 5;
//		p2.work();
		Person p2 = new Person("tony", 5, true);
		
		
//		System.out.println(p2.name + " : " + p2.age + " : " + p2.isHungry);
//		System.out.println(p1.name + " : " + p1.age + " : " + p1.isHungry);
		p1.printInfo();
		p2.printInfo();
		
//		p1 = new Person();  // 0x200
	}

}
