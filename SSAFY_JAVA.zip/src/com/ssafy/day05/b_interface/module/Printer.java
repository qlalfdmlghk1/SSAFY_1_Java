package com.ssafy.day05.b_interface.module;

public interface Printer {
    void print(String fileName);
}
