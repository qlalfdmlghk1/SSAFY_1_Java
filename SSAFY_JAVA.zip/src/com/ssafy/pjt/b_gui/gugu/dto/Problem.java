package com.ssafy.pjt.b_gui.gugu.dto;

public record Problem(int num1, int num2, int correctAnswer) {

}
