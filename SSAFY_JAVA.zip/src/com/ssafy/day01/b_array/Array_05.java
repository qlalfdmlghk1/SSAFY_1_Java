package com.ssafy.day01.b_array;

public class Array_05 {
    public static void main(String[] args) {
        int[] intArray = { 3, 27, 13, 8, 235, 7, 22, 9, 435, 31, 54 };

        // TODO: 위 배열의 요소 중 최대, 최소, 평균, 평균과 절대값의 차이가 가장 큰 값, 가장 작은 값을 출력하시오.
        //  단 평균은 소숫점 2째 자리까지 출력한다.

        // END

    }
}
