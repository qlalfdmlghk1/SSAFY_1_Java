package com.ssafy.day01.a_basic;

import java.util.ArrayList;

public class Basic_01 {

    public static void main(String[] args) {
        //var v; // 할당까지 같이 진행되어야 함
        int i = 10;
        var a = 1;
        var str = "Hello";
        var list2 = new ArrayList<>();
        var list3 = new ArrayList<String>();
    }
}
