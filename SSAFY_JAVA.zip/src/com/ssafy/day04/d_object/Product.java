package com.ssafy.day04.d_object;

import java.util.Objects;

public class Product {
    private String sn;

    public Product(String sn) {
        this.sn = sn;
    }

    // TODO: toString, equals, hashCode를 적절히 재정의해보자.

    // END
   

}
