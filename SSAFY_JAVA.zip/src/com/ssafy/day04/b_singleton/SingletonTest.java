package com.ssafy.day04.b_singleton;

class SingletonClass {
  // TODO:SingletonClass에 Singleton Design Pattern을 적용하시오.

  // END
  public void sayHello() {
    System.out.println("Hello");
  }

}

public class SingletonTest {
  public static void main(String[] args) {
    // TODO:SingletonClass를 사용해보세요.

    // END
  }
}
