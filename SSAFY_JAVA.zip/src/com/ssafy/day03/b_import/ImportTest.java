package com.ssafy.day03.b_import;

// TODO: import 되는 패키지들을 살펴보자.

// END

public class ImportTest {
    // TODO: 다음의 요청 사항들을 처리하시오.
    //  1. Object 타입의 객체를 선언해보자. import 되는 내용은?
    //  2. code assist를 통해 DateFormat 타입의 객체를 선언해보자.
    //  3. 아래 주석을 해지하고 오류를 수정해보자.
    //  File file;
    //  Date date;
    //  4. java.awt 패키지의 List 타입 변수를 선언해보자.
    //  5. java.util 패키지의 List 타입 변수를 선언해보자.

    // END
    public static void main(String[] args) {
        // TODO: static import를 통해 다음을 처리하시오.
        //  1. Math 클래스의 PI를 출력해보자.
        //  2. static import를 통해 10과 20 중 최대값을 출력해보자.
        //  3. code assist를 통해 10과 20 중 최소값을 출력해보자.

        // END
    }

}
