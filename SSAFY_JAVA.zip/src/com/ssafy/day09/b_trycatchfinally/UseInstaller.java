package com.ssafy.day09.b_trycatchfinally;

public class UseInstaller {
    public static void main(String[] args) {
        // TODO: InstallApp을 이용하면서 자원이 확실히 정리되도록 해보자.

        // END
        System.out.println("설치 종료");

    }
}
